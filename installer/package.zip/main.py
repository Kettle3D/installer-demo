from tkinter import *;
tk = Tk();
tk.title("Installer Demo");

def new_button():
	Button(tk, text="Create another button", command=new_button).pack();

new_button();

while True:
	tk.update_idletasks();
	tk.update();
